file_name = input("Enter file name: ")
fh = open(file_name, "w")
count = 0
while count < 10:
    line = input("type> ")
    fh.write(line)
    fh.write("\n")
    count += 1
fh.close()

